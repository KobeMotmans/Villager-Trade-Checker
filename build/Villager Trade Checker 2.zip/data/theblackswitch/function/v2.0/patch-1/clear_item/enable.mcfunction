execute unless function theblackswitch:v2.0/patch-1/version_control/is_latest run return fail
scoreboard players set #tbs-v2.0.enabled.clear_item tbs.server_data 1
